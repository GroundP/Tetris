﻿#include "Reference.h"
#include "TetrisHandler.h"

int main()
{
    CTetrisHandler TetrisHandler;
    TetrisHandler.run();

    //Reference reference;
    //reference.run();
    return 0;
}

